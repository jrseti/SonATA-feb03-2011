//void topdownsinglesum(short length,short height,signed char *lower,signed char *upper);
//void topdowndaddpair(short length,short drift,signed char *inrowlower,
//                     signed char *inrowupper);
void topdowngeneraldadd(short m,short length,signed char *data);
void splitpath(short length,short drift,signed char *lvec,signed char *uvec);
void topsolve(long length,short smallerblock,signed char *lvec,signed char *uvec);
void geninvdadd(short rowcount,short length,signed char *data);

